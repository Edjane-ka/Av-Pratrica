# Av-Pratica
Avalição Prática de um site de busca. Seus Layouts e Códigos.

<a href=https://www.figma.com/file/6GPOI8aIx6zRbuHO36Gd1I/Buscador?type=design&node-id=0%3A1&t=3GUpbGQG56RvYMp4-1> Layouts do Figma</a>

Buscador - ACHEAQUI

-Requisitos cumpridos-

1-Layout no figma/canva: fizemos o layout no figma e pegamos alguns elementos do canva.

2-Responsividade: usamos os breakpoints "container-lg"para monitores de computador e"container-md" para Tablets/Smartphones.

3-Pré-requisitos (rodapé, paginação, componets): colocamos o rodapé na tela de busca, inserimos a paginação na tela de resultado e de componentes usamos o buttom e a barra de pesquisa.

4-Criatividade e inovação: A logo, o rodapé, os links clicáveis. 
